TROLL BUDDY — Android floating pet starter project

WHAT IT DOES
- Adds a small animated troll companion over other apps.
- The pet gently bobs, can be dragged around the screen, and reacts when tapped.
- The design combines pink, blue and teal colours with colourful upright hair.
- A persistent notification is shown while the overlay is running.

IMPORTANT
This is Android source code, not an installable APK. It must be built and signed before it can be installed.
I cannot install it on your phone directly from this chat.

BUILD
1. Open this folder in Android Studio on a computer.
2. Let Gradle sync and install Android SDK Platform 35 if prompted.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated APK on your Android phone.
5. Open Troll Buddy, tap Allow floating window, enable “Display over other apps”, return, then tap Start Pet.

PHONE PERMISSION
Android Settings may show “Display over other apps” or “Appear on top”.
You can stop the pet from the app's Stop Pet button or by force-stopping the app.

NOTE
This is a starter build. Some Android manufacturers aggressively restrict background apps;
if the pet disappears, allow Troll Buddy to run in the background / disable battery
optimization for it in the phone's app settings.
