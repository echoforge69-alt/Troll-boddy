package com.example.trollbuddy

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import android.os.Handler
import android.os.Looper
import kotlin.math.sin

class TrollPetView(context: Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val handler = Handler(Looper.getMainLooper())
    private var tick = 0
    private var reaction = 0
    private val loop = object : Runnable {
        override fun run() { tick++; invalidate(); handler.postDelayed(this, 90) }
    }
    init { setLayerType(View.LAYER_TYPE_SOFTWARE, null); handler.post(loop) }

    fun react() { reaction = 1; invalidate(); handler.postDelayed({ reaction = 0; invalidate() }, 900) }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val sx = width / 180f
        val sy = height / 220f
        canvas.save(); canvas.scale(sx, sy)
        val bob = sin(tick / 5.0).toFloat() * 3f
        canvas.translate(0f, bob)
        // soft shadow
        p.color = 0x33222222; canvas.drawOval(RectF(38f, 194f, 144f, 210f), p)
        // tall colourful hair spikes
        val hair = Path().apply {
            moveTo(45f, 83f); lineTo(38f, 35f); lineTo(62f, 58f)
            lineTo(69f, 12f); lineTo(87f, 55f); lineTo(109f, 8f)
            lineTo(112f, 57f); lineTo(143f, 27f); lineTo(132f, 82f); close()
        }
        p.color = 0xff20b8b2; canvas.drawPath(hair, p)
        p.color = 0xffff70b7
        canvas.drawCircle(69f, 45f, 13f, p); canvas.drawCircle(109f, 40f, 14f, p)
        p.color = 0xff69d8d2
        canvas.drawCircle(87f, 30f, 10f, p)
        // ears and face
        p.color = 0xffff9bc9; canvas.drawCircle(40f, 112f, 17f, p); canvas.drawCircle(140f, 112f, 17f, p)
        p.color = 0xffffc0d9; canvas.drawOval(RectF(42f, 63f, 138f, 178f), p)
        // cheeks
        p.color = 0xffff7fac; canvas.drawCircle(62f, 132f, 10f, p); canvas.drawCircle(118f, 132f, 10f, p)
        // eyes
        p.color = 0xffffffff; canvas.drawOval(RectF(61f, 91f, 84f, 119f), p)
        canvas.drawOval(RectF(96f, 91f, 119f, 119f), p)
        p.color = 0xff24334a
        val eyeShift = if (reaction == 1) 2f else 0f
        canvas.drawCircle(74f + eyeShift, 105f, 7f, p); canvas.drawCircle(108f + eyeShift, 105f, 7f, p)
        p.color = 0xffffffff; canvas.drawCircle(76f + eyeShift, 102f, 2.5f, p); canvas.drawCircle(110f + eyeShift, 102f, 2.5f, p)
        // smile
        p.color = 0xff8f365d; p.style = Paint.Style.STROKE; p.strokeWidth = 3.5f
        val smile = Path().apply { moveTo(78f, 145f); quadTo(90f, if (reaction == 1) 164f else 159f, 104f, 145f) }
        canvas.drawPath(smile, p); p.style = Paint.Style.FILL
        // little teal body and pink hands
        p.color = 0xff31bdb5; canvas.drawRoundRect(RectF(59f, 169f, 121f, 202f), 18f, 18f, p)
        p.color = 0xffff91c5; canvas.drawCircle(49f, 184f, 11f, p); canvas.drawCircle(131f, 184f, 11f, p)
        canvas.restore()
    }
    override fun onDetachedFromWindow() { handler.removeCallbacks(loop); super.onDetachedFromWindow() }
}
