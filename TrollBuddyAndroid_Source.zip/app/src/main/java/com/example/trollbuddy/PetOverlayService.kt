package com.example.trollbuddy

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager

class PetOverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var petView: TrollPetView? = null
    private lateinit var params: WindowManager.LayoutParams

    override fun onCreate() {
        super.onCreate()
        startPetNotification()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        petView = TrollPetView(this)
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        params = WindowManager.LayoutParams(
            180, 220, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 220
        }
        petView?.setOnTouchListener(object : View.OnTouchListener {
            var downX = 0f
            var downY = 0f
            var startX = 0
            var startY = 0
            var moved = false
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = event.rawX; downY = event.rawY
                        startX = params.x; startY = params.y; moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - downX).toInt()
                        val dy = (event.rawY - downY).toInt()
                        if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > 8) moved = true
                        params.x = startX + dx; params.y = startY + dy
                        windowManager.updateViewLayout(petView, params)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) petView?.react()
                        return true
                    }
                }
                return false
            }
        })
        windowManager.addView(petView, params)
    }

    private fun startPetNotification() {
        val channelId = "troll_buddy_running"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "Troll Buddy", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, channelId)
        else @Suppress("DEPRECATION") Notification.Builder(this)
        notification.setContentTitle("Troll Buddy is floating")
            .setContentText("Tap the pet to make it react. Use Stop Pet to dismiss.")
            .setSmallIcon(android.R.drawable.star_on)
        startForeground(7, notification.build())
    }

    override fun onDestroy() {
        petView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        petView = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
