package com.example.trollbuddy

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.graphics.Color

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(250, 242, 255))
        }
        val title = TextView(this).apply {
            text = "🌈 Troll Buddy"
            textSize = 30f
            setTextColor(Color.rgb(60, 35, 80))
            gravity = Gravity.CENTER
        }
        val description = TextView(this).apply {
            text = "Your tiny pink, blue and teal troll companion.\n\nAllow overlay permission, then tap Start Pet. You can drag the pet around and tap it for reactions."
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(8, 24, 8, 24)
            setTextColor(Color.DKGRAY)
        }
        val permission = Button(this).apply {
            text = "Allow floating window"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName"))
                    startActivity(intent)
                }
            }
        }
        val start = Button(this).apply {
            text = "Start Pet"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startForegroundService(Intent(this@MainActivity, PetOverlayService::class.java))
                } else {
                    permission.performClick()
                }
            }
        }
        val stop = Button(this).apply {
            text = "Stop Pet"
            setOnClickListener {
                stopService(Intent(this@MainActivity, PetOverlayService::class.java))
            }
        }
        layout.addView(title)
        layout.addView(description)
        layout.addView(permission)
        layout.addView(start)
        layout.addView(stop)
        setContentView(layout)
    }
}
